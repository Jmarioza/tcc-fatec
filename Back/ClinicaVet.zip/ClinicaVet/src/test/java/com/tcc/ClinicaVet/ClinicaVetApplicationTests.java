package com.tcc.ClinicaVet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaVetApplicationTests {

	@Test
	void contextLoads() {
	}

}
