package com.tcc.ClinicaVet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaVetApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaVetApplication.class, args);
	}

}
